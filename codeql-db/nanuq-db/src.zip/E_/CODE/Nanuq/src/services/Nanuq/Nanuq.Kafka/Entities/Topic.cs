namespace Nanuq.Kafka.Entities;

public record Topic(string TopicName, int NumberOfPartitions);
