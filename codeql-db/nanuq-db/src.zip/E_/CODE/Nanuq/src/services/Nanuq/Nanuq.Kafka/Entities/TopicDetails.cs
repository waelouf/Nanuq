namespace Nanuq.Kafka.Entities;

public record TopicDetails(string TopicName, long NumberOfMessages);
